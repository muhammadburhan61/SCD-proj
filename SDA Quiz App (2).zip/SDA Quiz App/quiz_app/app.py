from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# ----- Quiz Questions by Subject -----
quiz_bank = {
    'web': [
        {'question': 'What does HTML stand for?',
         'options': ['Hyper Text Markup Language', 'Home Tool Markup Language', 'Hyperlinks and Text Markup Language'],
         'answer': 'Hyper Text Markup Language'},
        {'question': 'What does CSS stand for?',
         'options': ['Cascading Style Sheets', 'Creative Style Sheets', 'Computer Style Sheets'],
         'answer': 'Cascading Style Sheets'},
        {'question': 'Which HTML tag is used to create a hyperlink?',
         'options': ['<a>', '<link>', '<href>'],
         'answer': '<a>'},
        {'question': 'Which HTML element is used for the largest heading?',
         'options': ['<h6>', '<h1>', '<head>'],
         'answer': '<h1>'},
        {'question': 'Which CSS property changes the text color?',
         'options': ['font-color', 'text-color', 'color'],
         'answer': 'color'}
    ],
    'python': [
        {'question': 'What is the output of: print(2 ** 3)?', 'options': ['6', '8', '9'], 'answer': '8'},
        {'question': 'How do you start a comment in Python?', 'options': ['--', '#', '//'], 'answer': '#'},
        {'question': 'Which keyword is used to define a function?', 'options': ['function', 'def', 'define'], 'answer': 'def'},
        {'question': 'What data type is the value True?', 'options': ['str', 'int', 'bool'], 'answer': 'bool'},
        {'question': 'Which of the following is a list?', 'options': ['[1, 2, 3]', '{1, 2, 3}', '(1, 2, 3)'], 'answer': '[1, 2, 3]'}
    ],
    'ml': [
        {'question': 'What is supervised learning?', 'options': ['Learning with labeled data', 'Learning without data', 'Learning without labels'], 'answer': 'Learning with labeled data'},
        {'question': 'What does "k" represent in k-NN?', 'options': ['Number of clusters', 'Number of neighbors', 'Learning rate'], 'answer': 'Number of neighbors'},
        {'question': 'Which algorithm is mainly used for classification?', 'options': ['Linear Regression', 'Logistic Regression', 'PCA'], 'answer': 'Logistic Regression'},
        {'question': 'What is the purpose of a validation set?', 'options': ['Test model on unseen data', 'Train the model', 'Tune hyperparameters'], 'answer': 'Tune hyperparameters'},
        {'question': 'What is underfitting in machine learning?', 'options': ['Model fits training data too well', 'Model performs poorly on training data', 'Model performs perfectly'], 'answer': 'Model performs poorly on training data'}
    ]
}

# ----- DB Setup -----
def init_db():
    if not os.path.exists("users.db"):
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()

init_db()

# ----- Routes -----

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        hashed_pw = generate_password_hash(password)

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, hashed_pw))
            conn.commit()
        except sqlite3.IntegrityError:
            return "Email already registered!"
        finally:
            conn.close()
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT password FROM users WHERE email = ?", (email,))
        result = cursor.fetchone()
        conn.close()

        if result and check_password_hash(result[0], password):
            session['user'] = email
            return redirect(url_for('dashboard'))
        return "Invalid credentials"

    # GET request: just show the login page
    return render_template('login.html')


@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('index'))
    return render_template('home.html')

@app.route('/quiz/<subject>')
def quiz(subject):
    if 'user' not in session:
        return redirect(url_for('index'))
    if subject not in quiz_bank:
        return "Invalid subject"
    return render_template('quiz.html', subject=subject, questions=quiz_bank[subject])

@app.route('/submit/<subject>', methods=['POST'])
def submit(subject):
    if 'user' not in session:
        return redirect(url_for('index'))
    if subject not in quiz_bank:
        return "Invalid subject"
    questions = quiz_bank[subject]
    score = 0
    results = []
    for i, q in enumerate(questions):
        user_answer = request.form.get(f'question-{i}')
        correct = user_answer == q['answer']
        if correct:
            score += 1
        results.append({
            "question": q['question'],
            "user_answer": user_answer,
            "correct_answer": q['answer'],
            "is_correct": correct
        })
    passed = score >= len(questions) * 0.6
    return render_template('result.html', score=score, total=len(questions), passed=passed, results=results, subject=subject)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
